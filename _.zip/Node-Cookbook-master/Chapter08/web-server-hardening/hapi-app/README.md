# hapi-starter-kit
Starter kit for Hapi

## Install
```bash
git clone git@github.com:azaritech/hapi-starter-kit.git
cd hapi-starter-kit/
yarn install
# or
npm install
```

## Start
```bash
npm run start
```

### Open browser and go to
[http://localhost:3000/](http://localhost:3000/)

[http://localhost:3000/hello](http://localhost:3000/hello)
